package shoppingcart;

import static org.hamcrest.core.Is.is;
import static org.hamcrest.core.IsEqual.equalTo;
import org.junit.Test;
import shoppingcart.catalogue.Products;

import static org.junit.Assert.*;

public class CartTest {

    @Test
    public void testSingleProduct(){
        Cart cart=new Cart();
        assertThat(cart.items().isEmpty(),is(true));
        cart.addItems(Products.DOVE,5);
        assertThat(cart.items().size(),is(5));
        assertThat(cart.total(),equalTo(199.95));
    }

    @Test
    public void testSingleProductAddedTwice(){
        Cart cart=new Cart();
        assertThat(cart.items().isEmpty(),is(true));
        cart.addItems(Products.DOVE,5);
        cart.addItems(Products.DOVE,3);
        assertThat(cart.items().size(),is(8));
        assertThat(cart.total(),equalTo(319.92));
    }

}