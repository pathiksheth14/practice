package shoppingcart;

import org.apache.commons.math.util.MathUtils;
import shoppingcart.catalogue.Items;
import shoppingcart.catalogue.Products;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

public class Cart {
   private  Items items= new Items();

    public void addItems(Products products,int numberOfItems){
        items.add(products,numberOfItems);
    }

    public double total(){
        return MathUtils.round(items.stream().mapToDouble(item ->item.getPrice()).sum(), 2, BigDecimal.ROUND_HALF_DOWN);
    }

    public Items items(){
        return (Items) items.clone();
    }
}
