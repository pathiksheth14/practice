package shoppingcart.catalogue;

public enum Products {

    DOVE("Dove",39.99);

    private final String name;
    private final double price;

    private Products(String name, double price){
        this.name=name;
        this.price=price;
    }

    public double getPrice() {
        return price;
    }

    public String getName() {
        return name;
    }

    public Products getProduct(String name){
        for (Products product: Products.values()) {
            if(product.getName().equals(name)) return  product;
        }
        throw  new RuntimeException("Products not present in catalogue");
    }
}
