package shoppingcart.catalogue;

import java.util.ArrayList;
import java.util.stream.IntStream;

public class Items  extends ArrayList<Products>{

    public void add(Products products, int numberOfItem) {
        IntStream.range(0,numberOfItem).forEach(index ->{
            this.add(products);
        });
    }
}
